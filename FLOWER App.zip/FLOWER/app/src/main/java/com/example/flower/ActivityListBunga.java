package com.example.flower;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.Toast;

public class ActivityListBunga extends AppCompatActivity {
    ListView listbunga;

    String[] judulList = {
            "ldksjf",
            "ajdf",
            "akfj",
            "akljf",
            "kadjf",
            "kajf",
            "jkdfa",
            "kajfd",
            "akjf",
            "akdfj"
    };

    Integer[] gambarList = {
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size,
            R.drawable.shape_size

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_bunga);

        listbunga = findViewById(R.id.list_bunga);

        CustomListAdapter adapter = new CustomListAdapter(this, judulList, gambarList);
        listbunga.setAdapter(adapter);

        listbunga.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Toast.makeText(getApplicationContext(), "anda memilih" + judulList[position],
                        Toast.LENGTH_SHORT).show();

            }
        });
    }
}



